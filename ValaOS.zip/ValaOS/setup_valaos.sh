#!/bin/bash

# Define el nombre de la distribución y la versión
distro_name="ValaOS"
distro_version="Uranus"
script_dir="$(dirname "$(readlink -f "$0")")"
logo_grub="valaos_grub.tga"
logo_lightdm="valaos_lightdm.png"
plymouth_theme_dir="/usr/share/plymouth/themes/valaos"
plymouth_logo="valaos_plymout.png"
ascii_logo="valaos_neofetch.txt"
image_logo="valaos_neofetch.png"

# Copiar imágenes a los directorios correspondientes
sudo cp "$script_dir/$logo_grub" /boot/grub/
sudo cp "$script_dir/$logo_lightdm" /usr/share/images/
sudo cp "$script_dir/$plymouth_logo" /usr/share/plymouth/themes/valaos/
sudo cp "$script_dir/$ascii_logo" /usr/share/neofetch/
sudo cp "$script_dir/$image_logo" /usr/share/neofetch/

# Actualizar la información del sistema
sudo sed -i "s/Ubuntu 22.04 LTS/$distro_name $distro_version/g" /etc/os-release

# Personalizar GRUB
echo "GRUB_BACKGROUND=\"/boot/grub/$logo_grub\"" | sudo tee -a /etc/default/grub
sudo update-grub

# Configurar LightDM (si está instalado)
if [ -f /etc/lightdm/lightdm-gtk-greeter.conf ]; then
    sudo sed -i "s/^background=.*/background=\/usr\/share\/images\/$logo_lightdm/g" /etc/lightdm/lightdm-gtk-greeter.conf
fi

# Mensaje de bienvenida personalizado en la consola
echo "Bienvenido a $distro_name $distro_version" | sudo tee /etc/motd

# Instalar y configurar Neofetch
sudo apt-get install -y neofetch
echo "info \"Image\" \"ascii\" \"/usr/share/neofetch/$ascii_logo\"" | sudo tee ~/.config/neofetch/config.conf

# Instalar Plymouth y configurar el tema personalizado
sudo apt-get install -y plymouth plymouth-themes

# Crear el directorio del tema
sudo mkdir -p $plymouth_theme_dir

# Crear el archivo de tema de Plymouth
cat << EOF | sudo tee $plymouth_theme_dir/valaos.plymouth
[Plymouth Theme]
Name=ValaOS Theme
Description=This theme uses a custom logo for ValaOS
ModuleName=script

[script]
ImageDir=$plymouth_theme_dir
ScriptFile=$plymouth_theme_dir/valaos.script
EOF

# Crear el script que controlará la animación
cat << 'EOF' | sudo tee $plymouth_theme_dir/valaos.script
wallpaper_image = Image("valaos-plymouth.png");
screen_width = Window.GetWidth();
screen_height = Window.GetHeight();
resized_wallpaper_image = wallpaper_image.Scale(screen_width, screen_height);
wallpaper_sprite = Sprite(resized_wallpaper_image);
wallpaper_sprite.SetZ(-100);
EOF

# Configurar Plymouth para usar el nuevo tema
sudo plymouth-set-default-theme -R valaos

echo "Personalización completada. Por favor reinicie su sistema."
