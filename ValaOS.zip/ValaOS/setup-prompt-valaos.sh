#!/bin/bash

# Agregar la personalización del prompt a .bashrc para que sea permanente
echo 'export PS1="ValaOS \[\e[32m\]\u@\h\[\e[m\]:\[\e[34m\]\w\[\e[m\] \[\e[35m\]>\[\e[m\] "' >> ~/.bashrc

# Recargar .bashrc para aplicar los cambios
source ~/.bashrc

echo "El prompt de la terminal ahora muestra 'ValaOS'."
