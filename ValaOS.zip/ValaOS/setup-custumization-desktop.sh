#!/bin/bash

# Ruta del directorio donde se encuentra este script
script_dir="$(dirname "$(readlink -f "$0")")"

# Define los nombres y rutas de los archivos de temas e iconos
tema_xfce="uranus"
iconos_xfce="Fluent"
tema_metacity="uranus"
fondo_escritorio="valaos-uranus-wallpaper.jpg"
nuevo_icono_whisker="valaos_logo.png"

# Copiar temas e iconos al sistema
sudo cp -r "$script_dir/$tema_xfce" /usr/share/themes/
sudo cp -r "$script_dir/$iconos_xfce" /usr/share/icons/
sudo cp -r "$script_dir/$tema_metacity" /usr/share/themes/
sudo cp "$script_dir/$fondo_escritorio" /usr/share/backgrounds/
sudo cp "$script_dir/$nuevo_icono_whisker" /usr/share/icons/

# Configurar el tema de XFCE
xfconf-query -c xsettings -p /Net/ThemeName -s "$tema_xfce"

# Configurar el tema de iconos
xfconf-query -c xsettings -p /Net/IconThemeName -s "$iconos_xfce"

# Configurar el tema de Metacity
gsettings set org.gnome.desktop.wm.preferences theme "$tema_metacity"

# Establecer el fondo de escritorio
xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/last-image -s "/usr/share/backgrounds/$fondo_escritorio"

# Instalar Vala Panel AppMenu
sudo apt-get install -y vala-panel-appmenu-common vala-panel-appmenu-registrar xfce4-vala-panel-appmenu-plugin

# Configuración del panel inferior al estilo Windows 11
panel_id=$(xfconf-query -c xfce4-panel -p /panels --create -t int -s 1)
xfconf-query -c xfce4-panel -p /panels/panel-$panel_id/position -s "p=6;x=0;y=0"
xfconf-query -c xfce4-panel -p /panels/panel-$panel_id/position-locked -s true
xfconf-query -c xfce4-panel -p /panels/panel-$panel_id/length -s 100
xfconf-query -c xfce4-panel -p /panels/panel-$panel_id/length-adjust -s true
xfconf-query -c xfce4-panel -p /panels/panel-$panel_id/size -s 32
xfconf-query -c xfce4-panel -p /panels/panel-$panel_id/plugin-ids -s -t int -a 1 2 3
xfconf-query -c xfce4-panel -p /plugins/plugin-1 -t string -s "whiskermenu" --create
xfconf-query -c xfce4-panel -p /plugins/plugin-1/button-icon -s "/usr/share/icons/$nuevo_icono_whisker"
xfconf-query -c xfce4-panel -p /plugins/plugin-2 -t string -s "separator" --create
xfconf-query -c xfce4-panel -p /plugins/plugin-2/expand -s true
xfconf-query -c xfce4-panel -p /plugins/plugin-3 -t string -s "tasklist" --create

# Configuración del segundo panel en la parte superior para Vala Panel AppMenu
upper_panel_id=$(xfconf-query -c xfce4-panel -p /panels --create -t int -s 2)
xfconf-query -c xfce4-panel -p /panels/panel-$upper_panel_id/position -s "p=8;x=0;y=0"
xfconf-query -c xfce4-panel -p /panels/panel-$upper_panel_id/position-locked -s true
xfconf-query -c xfce4-panel -p /panels/panel-$upper_panel_id/length -s 100
xfconf-query -c xfce4-panel -p /panels/panel-$upper_panel_id/length-adjust -s true
xfconf-query -c xfce4-panel -p /panels/panel-$upper_panel_id/size -s 24
appmenu_plugin_id=4  # Asegúrate de que este ID es correcto y único
xfconf-query -c xfce4-panel -p /plugins/plugin-$appmenu_plugin_id -t string -s "vala-panel-appmenu" --create

# Reiniciar el panel para aplicar los cambios
xfce4-panel -r

echo "Personalización de XFCE y Metacity completada."
