#!/bin/bash

# Actualizar el sistema
sudo apt-get update && sudo apt-get upgrade -y

# Instalar Xorg, XFCE, Metacity, Picom y LightDM
sudo apt-get install -y xorg xfce4 xfce4-goodies lightdm lightdm-gtk-greeter metacity picom

# Configurar LightDM para usar XFCE con un nombre personalizado
echo "[Seat:*]
user-session=vala-desktop
greeter-session=lightdm-gtk-greeter" | sudo tee /etc/lightdm/lightdm.conf.d/99-vala-desktop.conf

# Crear el archivo de sesión para "vala-desktop"
mkdir -p ~/.config/vala-desktop
echo "#!/bin/bash
xfce4-session
metacity --replace &
picom &" | tee ~/.config/vala-desktop/vala-desktop-session

# Hacer ejecutable el script de sesión
chmod +x ~/.config/vala-desktop/vala-desktop-session

# Crear una entrada de sesión para LightDM
echo "[Desktop Entry]
Name=Vala Desktop
Comment=Start XFCE with Metacity and Picom
Exec=/home/$USER/.config/vala-desktop/vala-desktop-session
Type=Application" | sudo tee /usr/share/xsessions/vala-desktop.desktop

echo "Configuración completada. Por favor reinicie su sistema."
