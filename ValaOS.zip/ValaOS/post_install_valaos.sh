#!/bin/bash

# Actualizar los paquetes existentes
sudo apt update && sudo apt upgrade -y

# Instalar herramientas y utilidades básicas
packages="tar gzip bzip2 unrar p7zip-full grub2 git"
for pkg in $packages; do
    if ! dpkg -l | grep -qw $pkg; then
        echo "Instalando $pkg..."
        sudo apt install -y $pkg
    else
        echo "$pkg ya está instalado."
    fi
done

# Instalar controladores adicionales (genéricos para nuevos y antiguos dispositivos)
sudo apt install -y firmware-linux firmware-linux-nonfree firmware-misc-nonfree

# Detectar hardware gráfico y decidir qué controladores instalar
gpu=$(lspci | grep -e VGA -e 3D)

if [[ $gpu == *"NVIDIA"* ]]; then
    echo "Instalando controladores para Nvidia..."
    sudo add-apt-repository ppa:graphics-drivers/ppa -y
    sudo apt update
    sudo apt install -y nvidia-driver-460  # Asegúrate de elegir la versión adecuada
elif [[ $gpu == *"AMD"* ]]; then
    echo "Instalando controladores para AMD..."
    sudo add-apt-repository ppa:oibaf/graphics-drivers -y
    sudo apt update
    sudo apt install -y xserver-xorg-video-amdgpu
fi

echo "Instalación de software y controladores completada."
