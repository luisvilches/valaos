#!/bin/bash

# Establecer el directorio del script como directorio de trabajo
cd "$(dirname "$0")"

# Lista de scripts a ejecutar
scripts=(
    "setup_vala-desktop.sh"
    "setup_valaos.sh"
    "setup-custumization-desktop.sh"
    "setup-prompt-valaos.sh"
    "post_install_valaos.sh"
)

# Ejecutar cada script en la lista
for script in "${scripts[@]}"; do
    if [ -f "$script" ]; then
        echo "Ejecutando $script..."
        chmod +x "$script"  # Asegurarse de que el script sea ejecutable
        ./"$script"
    else
        echo "Error: No se encontró el script '$script'."
    fi
done

echo "Todos los scripts han sido ejecutados."
